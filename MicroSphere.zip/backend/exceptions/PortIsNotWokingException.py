class PortIsNotWokingException(Exception):
    pass