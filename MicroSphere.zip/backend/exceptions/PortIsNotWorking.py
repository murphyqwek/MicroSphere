class PortIsNotWorking(Exception):
    pass