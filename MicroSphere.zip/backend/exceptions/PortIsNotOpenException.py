class PortIsNotOpenException(Exception):
    pass