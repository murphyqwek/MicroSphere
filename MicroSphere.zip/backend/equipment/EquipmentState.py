import enum

class EquipmentState(enum.Enum):
    WORKING = 1
    STOPPED = 2
    ERROR = 3